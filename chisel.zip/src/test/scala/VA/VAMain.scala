
package VA
import chisel3._


object VAMain extends App{
iotesters.Driver.execute(args,() => new Conv(32,5,5,3)){
c => new ConvTest(c)
}
}
